from django.urls import include, path
from . import views


app_name = 'mimitapp'
urlpatterns = [
    path("", views.index, name="index"),
    path('<int:post_id>', views.detalhe, name='detalhe'),
    path('<int:post_id>/deletepost', views.deletepost, name='deletepost'),
    path('criarpost', views.criarpost, name='criarpost'),
    path('submitpost', views.submitpost, name='submitpost'),
    path('loginutilizador/', views.loginutilizador, name="loginutilizador"),
    path('perfilutilizador/', views.perfilutilizador, name="perfilutilizador"),
    path('registoutilizador/', views.registoutilizador, name="registoutilizador"),
    path('guardarregistoutilizador/', views.guardarregistoutilizador, name="guardarregistoutilizador"),
    path('logoututilizador/', views.logoututilizador, name="logoututilizador"),
    path('noperms/', views.noperms, name="noperms"),
    path('<int:post_id>/criarcomment', views.criarcomment, name='criarcomment'),
    path('<int:post_id>/submitcomment', views.submitcomment, name='submitcomment'),
    path('<int:post_id>/likepost', views.likepost, name='likepost')
]
