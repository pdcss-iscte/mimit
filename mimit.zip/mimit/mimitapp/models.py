from django.contrib.auth.models import User
from django.db import models
from django.utils import timezone
from six import string_types
import datetime


class Post(models.Model):
    post_title = models.CharField(max_length=200)
    post_img = models.CharField(max_length=200)
    post_text = models.CharField(max_length=200)
    post_date = models.DateTimeField('Data do post')
    post_author = models.ForeignKey(User, on_delete=models.CASCADE)
    post_likes = models.ManyToManyField(User, related_name='blog_posts')

    def __str__(self):
        return self.post_title + ' | ' + str(self.post_author)

    def foi_publicada_recentemente(self):
        return self.post_date >= timezone.now() - datetime.timedelta(days=1)

    def get_likes(self):
        return self.post_likes.count()


class Comment(models.Model):
    post = models.ForeignKey(Post, related_name="comments", on_delete=models.CASCADE)
    comment_text = models.CharField(max_length=200)
    comment_date = models.DateTimeField('Data do comment')
    comment_author = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.comment_text + ' | ' + str(self.comment_author)
