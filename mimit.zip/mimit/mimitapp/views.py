from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import permission_required, login_required
from django.core.files.storage import FileSystemStorage
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.models import User
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.template import loader
from django.urls import reverse
from django.utils import timezone

from .models import Post, Comment


def index(request):
    latest_posts_list = Post.objects.order_by('-post_date')
    context = {'latest_posts_list': latest_posts_list, }
    return render(request, 'mimitapp/index.html', context)


def detalhe(request, post_id):
    post = get_object_or_404(Post, pk=post_id)
    liked = post.post_likes.filter(id=request.user.id).exists()
    context = {'post': post, 'liked': liked}
    return render(request, 'mimitapp/detalhe.html', context)


def criarpost(request):
    return render(request, 'mimitapp/criarpost.html')


def submitpost(request):
    title = request.POST['title']
    text = request.POST['text']
    img = request.POST['img']
    novopost = Post(post_title=title, post_img=img, post_text=text,
                    post_date=timezone.now(), post_author=User(request.user.id))
    novopost.save()
    return HttpResponseRedirect(reverse('mimitapp:index'))


def registoutilizador(request):
    return render(request, 'mimitapp/registoutilizador.html')


def guardarregistoutilizador(request):
    username = request.POST['username']
    email = request.POST['email']
    password = request.POST['password']
    user = User.objects.create_user(username, email, password)
    login(request, user)
    return HttpResponseRedirect(reverse('mimitapp:index'))


def loginutilizador(request):
    if request.method == 'POST':
        user = authenticate(username=request.POST['username'], password=request.POST['password'])
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse('mimitapp:index'))
        else:
            return render(request, 'mimitapp/loginutilizador.html')
    else:
        return render(request, 'mimitapp/loginutilizador.html')


def perfilutilizador(request):
    return render(request, 'mimitapp/perfilutilizador.html')


def logoututilizador(request):
    logout(request)
    return HttpResponseRedirect(reverse('mimitapp:index'))


def deletepost(request, post_id):
    post = Post.objects.get(pk=post_id)
    print(post)
    if request.user == post.post_author:
        post.delete()
        return HttpResponseRedirect(reverse('mimitapp:index'))
    else:
        return HttpResponseRedirect(reverse('mimitapp:noperms'))


def noperms(request):
    return render(request, 'mimitapp/noperms.html')


def criarcomment(request, post_id):
    post = get_object_or_404(Post, pk=post_id)
    return render(request, 'mimitapp/criarcomment.html', {'post': post})


def submitcomment(request, post_id):
    text = request.POST['text']
    novocomment = Comment(comment_text=text, comment_author=User(request.user.id),
                          comment_date=timezone.now(), post=Post.objects.get(pk=post_id))
    novocomment.save()
    return HttpResponseRedirect(reverse('mimitapp:index'))


def likepost(request, post_id):
    post = get_object_or_404(Post, id=request.POST.get('post_id'))
    if post.post_likes.filter(id=request.user.id).exists():
        post.post_likes.remove(request.user)
    else:
        post.post_likes.add(request.user)
    return HttpResponseRedirect(reverse('mimitapp:detalhe', args=[str(post_id)]))
